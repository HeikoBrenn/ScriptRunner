﻿#Requires -Version 5.0
#Requires -Modules ActiveDirectory

<#
    .Synopsis
        Sets properties for a AD user

    .Description
        
    .COMPONENT
        Requires Module ActiveDirectory

    .Parameter UserSamAccountName
        [sr-en] Specifies the SamAccountName of the user
        [sr-de] SamAccountName des Benutzers

    .Parameter User
        [sr-en] User object, searched by the Query Search-ADUser
        [sr-de] Benutzer, ausgewählt mit der Query Search-ADUser

    .Parameter Fax
        [sr-en] Specifies the user's fax number, e.g. +49763776699
        [sr-de] Faxnummer des Benutzers, z.B. +49763778899

    .Parameter TelephoneNumber
        [sr-en] Specifies the user's telephone number, e.g. +49763776699
        [sr-de] Telefonnummer des Benutzers, z.B. +49763778899

    .Parameter OtherPager
        [sr-en] Mailaddress (john.doe@contoso.com)
        [sr-de] Mailadresse (john.doe@contoso.com) des Benutzers

    .Parameter Title
        [sr-en] Specifies the user's title
        [sr-de] Titel des Benutzers

    .Parameter MailAddress
        [sr-en] Specifies the user's mail address
        [sr-de] E-Mailadresse des Benutzers

    .Parameter Manager
        [sr-en] Distinguished name, SID, Guid, SamAccountName of the user's manager.
        [sr-de] Distinguished Name, SID, Guid, SamAccountName des Managers des Benutzers

    .Parameter Description
        [sr-en] Specifies the user's description
        [sr-de] Beschreibung des Benutzers

    .Parameter AccountExpirationDate 
        [sr-en] Specifies the user's account expiration date
        [sr-de] Ablaufdatum des Benutzerkontos

    .Parameter Company
        [sr-en] Specifies the user's company
        [sr-de] Firma des Benutzers

    .Parameter Location
        [sr-en] Specifies the user's location
        [sr-de] Standort des Benutzers

    .Parameter Street
        [sr-en] Specifies the user's street address
        [sr-de] Strasse des Benutzers

    .Parameter PostalCode
        [sr-en] Specifies the user's postal code
        [sr-de] PLZ des Benutzers

    .Parameter City
        [sr-en] Specifies the user's city
        [sr-de] Stadt des Benutzers

    .Parameter Enabled
        [sr-en] Account is enabled
        [sr-de] Benutzerkonto de-/aktivieren

    .Parameter DomainAccount    
        [sr-en] Active Directory Credential for remote execution without CredSSP
        [sr-de] Active Directory-Benutzerkonto für die Remote-Ausführung ohne CredSSP        

    .Parameter DomainName
        [sr-en] Name of Active Directory Domain
        [sr-de] Name der Active Directory Domäne 

    .Parameter AuthType
        [sr-en] Specifies the authentication method to use
        [sr-de] Gibt die zu verwendende Authentifizierungsmethode an
#>

param(
    [PSCredential]$DomainAccount,  
    [string]$DomainName,
    [ValidateSet('Basic', 'Negotiate')]
    [string]$AuthType = "Negotiate",
    [Parameter(Mandatory = $true, HelpMessage="ASRDisplay(Splatting)")]
    [hashtable]$User,
	[Parameter(Mandatory = $true,HelpMessage='ASRDisplay(Alias=SamAccountName)')]
    [string]$UserSamAccountName,
    [Parameter(HelpMessage='ASRDisplay(Alias=Fax)')]
    [ValidatePattern('^\+([0-9]{8,20})$')]
    [string]$Fax,
    [Parameter(HelpMessage='ASRDisplay(Alias=telephoneNumber)')]
    [ValidatePattern('^\+([0-9]{8,20})$')]
    [string]$TelephoneNumber,
    [Parameter(HelpMessage='ASRDisplay(Alias=otherPager)')]
    [ValidatePattern('^([a-zA-Z0-9]+)\.([A-za-z0-9)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$')]
    [string]$OtherPager,
    [Parameter(HelpMessage='ASRDisplay(Alias=Title)')]
    [string]$Title,
    [Parameter(HelpMessage='ASRDisplay(Alias=mail)')]
    [string]$MailAddress,
    [Parameter(HelpMessage='ASRDisplay(Alias=Manager)')]
    [string]$Manager,
    [Parameter(HelpMessage='ASRDisplay(Alias=physicalDeliveryOfficeName)')]
    [string]$Location,
    [Parameter(HelpMessage='ASRDisplay(Alias=Description)')]
    [string]$Description,
    [Parameter(HelpMessage='ASRDisplay(Date)')]
    [datetime]$AccountExpirationDate,
    [Parameter(HelpMessage='ASRDisplay(Alias=Company)')]
    [string]$Company,
    [Parameter(HelpMessage='ASRDisplay(Alias=StreetAddress)')]
    [string]$Street,
    [Parameter(HelpMessage='ASRDisplay(Alias=PostalCode)')]
    [string]$PostalCode,
    [Parameter(HelpMessage='ASRDisplay(Alias=City)')]
    [string]$City,
    [Parameter(HelpMessage='ASRDisplay(Alias=Enabled)')]
    [bool]$Enabled
)

Import-Module ActiveDirectory

try{
    [hashtable]$cmdArgs = @{'ErrorAction' = 'Stop'
                            'AuthType' = $AuthType
                            }
    if($null -ne $DomainAccount){
        $cmdArgs.Add("Credential", $DomainAccount)
    }
    if([System.String]::IsNullOrWhiteSpace($DomainName) -eq $true){
        $cmdArgs.Add("Current", 'LocalComputer')
    }
    else {
        $cmdArgs.Add("Identity", $DomainName)
    }    
    $domain = Get-ADDomain @cmdArgs

    [hashtable]$cmdArgs = @{
                            'AuthType' = $AuthType
                            'Identity' = $UserSamAccountName
							'Server' = $domain.PDCEmulator
                            }
    if($null -ne $DomainAccount){
        $cmdArgs.Add("Credential", $DomainAccount)
    }
    $userObj = Get-ADUser @cmdArgs -Properties * -ErrorAction Stop    

    [string[]]$clearParas = @()
    [hashtable]$replaceParas = @{}
    $cmdArgs.Add('ErrorAction', 'Stop')
    $cmdArgs.Add("Confirm", $false)    
    if([System.String]::IsNullOrEmpty($Fax) -eq $true){
        $clearParas += 'facsimileTelephoneNumber'
		$result += "Fax cleared"
    }
    else{
        if($userObj.Fax -cne $Fax){
            $cmdArgs.Add("Fax", $Fax)
        }
		$result =+ "fax set from  $($userObj.Fax) to $($fax)"
    }     
    if([System.String]::IsNullOrEmpty($otherPager) -eq $true){
        $clearParas += 'otherPager'
    }
    else{
        if($userObj.otherPager -cne $otherPager){
            $replaceParas.Add("otherPager", $otherPager)
        }
    } 
    if([System.String]::IsNullOrEmpty($TelephoneNumber) -eq $true){
        $clearParas += 'telephoneNumber'
    }
    else{
        if($userObj.telephoneNumber -cne $TelephoneNumber){
            $replaceParas.Add("telephoneNumber", $TelephoneNumber)
        }
    } 
	if($userObj.Enabled -ne $Enabled){
		$cmdArgs.Add("Enabled", $Enabled)
	}
	if($PSBoundParameters.ContainsKey('AccountExpirationDate') -eq $true){
		$cmdArgs.Add("AccountExpirationDate", $AccountExpirationDate)
	}
	if([System.String]::IsNullOrEmpty($userObj.mailNickname) -eq $true){
		if([System.String]::IsNullOrEmpty($MailAddress) -eq $true){
			$clearParas += 'EmailAddress'
		}
		else{
			if($userObj.EmailAddress -cne $MailAddress){
				$cmdArgs.Add("EmailAddress", $MailAddress)
			}
		}    
	}
	if([System.String]::IsNullOrEmpty($Description) -eq $true){
		$clearParas += 'Description'
	}
	else{
		if($userObj.Description -cne $Description){
			$cmdArgs.Add("Description", $Description)
		}
	}      
	if([System.String]::IsNullOrEmpty($Title) -eq $true){
		$clearParas += 'Title'
	}
	else{
		if($userObj.Title -cne $Title){
			$cmdArgs.Add("Title", $Title)
		}
	}     
	if([System.String]::IsNullOrEmpty($Manager) -eq $true){
		$clearParas += 'Manager'
	}
	else{
		if($userObj.Manager -cne $Manager){
			$cmdArgs.Add("Manager", $Manager)
		}
	}    
	if([System.String]::IsNullOrEmpty($Company) -eq $true){
		$clearParas += 'Company'
	}
	else{
		if($userObj.Company -cne $Company){
			$cmdArgs.Add("Company", $Company)
		}
	}
	if([System.String]::IsNullOrEmpty($Street) -eq $true){
		$clearParas += 'StreetAddress'
	}
	else{
		if($userObj.StreetAddress -cne $Street){
			$cmdArgs.Add("StreetAddress", $Street)
		}
	}
	if([System.String]::IsNullOrEmpty($PostalCode) -eq $true){
		$clearParas += 'PostalCode'
	}
	else{
		if($userObj.PostalCode -cne $PostalCode){
			$cmdArgs.Add("PostalCode", $PostalCode)
		}
	}
	if([System.String]::IsNullOrEmpty($City) -eq $true){
		$clearParas += 'City'
	}
	else{
		if($userObj.City -cne $City){
			$cmdArgs.Add("City", $City)
		}
	}
    
    if($clearParas.Count -gt 0){ # clear attributes
        $cmdArgs.Add("Clear", $clearParas)
    }
    if($replaceParas.Count -gt 0){ # replace attribute values
        $cmdArgs.Add("Replace", $replaceParas)
    }
    
    # change user
    $result = Set-ADUser @cmdArgs -PassThru 
    
    if($null -ne $SRXEnv){
        $SRXEnv.ResultMessage = $result    
    }
    else{
        Write-Output $result
    }
}
catch{
    throw
}