﻿#Requires -Version 5.0
#Requires -Modules ActiveDirectory

<#
    .SYNOPSIS
        Gets the user properties
    
    .DESCRIPTION  

    .COMPONENT
        Requires Module ActiveDirectory

    .Parameter OUPath
        [sr-en] SamAccountName of the user
        [sr-de] SamAccountName des Benutzers

    .Parameter DomainAccount
        [sr-en] Active Directory Credential for remote execution on jumphost without CredSSP
        [sr-de] Active Directory-Benutzerkonto für die Remote-Ausführung ohne CredSSP        

    .Parameter DomainName
        [sr-en] Name of Active Directory Domain
        [sr-de] Name der Active Directory Domäne
        
    .Parameter SearchScope
        [sr-en] Specifies the scope of an Active Directory search
        [sr-de] Gibt den Suchumfang einer Active Directory-Suche an
    
    .Parameter AuthType
        [sr-en] Specifies the authentication method to use
        [sr-de] Gibt die zu verwendende Authentifizierungsmethode an
#>

param(
    [string]$SamAccountName,  
    [string]$DomainName,
    [PSCredential]$DomainAccount,
    [ValidateSet('Basic', 'Negotiate')]
    [string]$AuthType = "Negotiate"
)

Import-Module ActiveDirectory

try{
    [string[]]$Properties = @('AccountExpirationDate','accountExpires','AccountLockoutTime','AccountNotDelegated','AllowReversiblePasswordEncryption','BadLogonCount','badPasswordTime',
                            'badPwdCount','CannotChangePassword','CanonicalName','City','CN','codePage','Company','Country','countryCode','Created','createTimeStamp','Deleted','Department',
                            'Description','DisplayName','DistinguishedName','Division','DoesNotRequirePreAuth','EmailAddress','EmployeeID','EmployeeNumber','employeeType','Enabled',
                            'extensionAttribute12','extensionAttribute8','extensionAttribute9','Fax','GivenName','HomeDirectory','HomeDrive','HomePage','HomePhone','Initials','isDeleted',
                            'l','LastBadPasswordAttempt','lastLogoff','lastLogon','LastLogonDate','lastLogonTimestamp','LockedOut','lockoutTime','logonCount','LogonWorkstations',
                            'mail','mailNickname','Manager','MobilePhone','Modified','modifyTimeStamp','Name','Office','OfficePhone','Organization','OtherName','otherPager',
                            'PasswordExpired','PasswordLastSet','PasswordNeverExpires','PasswordNotRequired','personalTitle','POBox','PostalCode','PrimaryGroup','ProfilePath','pwdLastSet','SamAccountName','showInAddressBook',
                            'TelephoneNumber','sn','State','StreetAddress','physicalDeliveryOfficeName','Surname','Title','UserPrincipalName','whenChanged','whenCreated')
    [hashtable]$cmdArgs = @{'ErrorAction' = 'Stop'
                            'AuthType' = $AuthType
                            }
    if($null -ne $DomainAccount){
        $cmdArgs.Add("Credential", $DomainAccount)
    }
    if([System.String]::IsNullOrWhiteSpace($DomainName) -eq $true){
        $cmdArgs.Add("Current", 'LocalComputer')
    }
    else {
        $cmdArgs.Add("Identity", $DomainName)
    }
    $Domain = Get-ADDomain @cmdArgs

    $cmdArgs = @{'ErrorAction' = 'Stop'
                'Server' = $Domain.PDCEmulator
                'AuthType' = $AuthType
                'Properties' = '*'
                }
    if($null -ne $DomainAccount){
        $cmdArgs.Add("Credential", $DomainAccount)
    }   
    if($PSBoundParameters.ContainsKey('SamAccountName') -eq $false){         
        $cmdArgs.Add('Filter',"*" )
    }
    else{
        $cmdArgs.Add('Identity', $SamAccountName)
    }             
    $users = Get-ADUser @cmdArgs 

    if($null -ne $SRXEnv) { 
        foreach($usr in $users){
            [hashtable]$props = @{}
            foreach($itmProp in $Properties){  
                if($null -eq $usr.Item($itmProp).Value){
                    $null = $props.Add($itmProp,'')
                }
                elseif($usr.Item($itmProp).Value.GetType().Name -eq 'Boolean'){
                    $null = $props.Add($itmProp,"`$$($usr.Item($itmProp).Value.toString().toLower())")
                }
                else{
                    $null = $props.Add($itmProp,$usr.Item($itmProp).Value)
                }
            }
            
            $null = $SRXEnv.ResultList.Add($props) # Value
            $null = $SRXEnv.ResultList2.Add("$($usr.DisplayName) ($($usr.SamAccountName))") # DisplayValue            
        }
    }
    else{
        Write-Output "$($user.DisplayName) ($($user.SamAccountName))"
    }
}
catch{
    throw
}
finally{
}