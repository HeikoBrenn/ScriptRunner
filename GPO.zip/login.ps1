﻿$key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
Set-ItemProperty $key Hidden 1
Set-ItemProperty $key HideFileExt 0
Set-ItemProperty $key ShowSuperHidden 1
Stop-Process -processname explorer

#region Add Windows languages
$LanguageList = Get-WinUserLanguageList
$LanguageList.Add("fr-FR")
$LanguageList.Add("es-ES")
$LanguageList.Add("pt-PT")
$LanguageList.Add("cs-CZ")
$LanguageList.Add("it-IT")
$LanguageList.Add("lt-LT")
Set-WinUserLanguageList $languagelist -Force
#endregion
Start-Process Explorer.exe